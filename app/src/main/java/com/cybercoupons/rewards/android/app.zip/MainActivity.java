package com.cybercoupons.rewards.android;
//package com.clover.optin.ccrewards;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.OperationCanceledException;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.SystemClock;
import android.provider.Settings.Secure;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnKeyListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.clover.sdk.util.CloverAccount;
import com.clover.sdk.util.CloverAuth;
import com.clover.sdk.util.Platform;
import com.clover.sdk.v1.BindingException;
import com.clover.sdk.v1.ClientException;
import com.clover.sdk.v1.ResultStatus;
import com.clover.sdk.v1.ServiceException;
import com.clover.sdk.v1.merchant.Merchant;
import com.clover.sdk.v1.merchant.MerchantConnector;
import com.clover.sdk.v1.tender.Tender;
import com.clover.sdk.v1.tender.TenderConnector;
import com.clover.sdk.v3.employees.Employee;
import com.clover.sdk.v3.employees.EmployeeConnector;

import java.net.URLEncoder;
import java.util.List;

public class MainActivity extends Activity implements EmployeeConnector.OnActiveEmployeeChangedListener{
    private static final int REQUEST_ACCOUNT = 1;
    public static final int OAUTH_REQUEST_CODE = 2;

    private TenderConnector tenderConnector;
    private EmployeeConnector mEmployeeConnector;
    private MerchantConnector mMerchantDemographics;
    private Account mMerchAccount;
    private CloverAuth.AuthResult mCloverAuth;
    private TextView resultText;
    private String orderId;
    private String merchantId;
    public static final String PREFS_NAME = "CyberPrefs";
    private ValueCallback<Uri> mUploadMessage;
    private final static int FILECHOOSER_RESULTCODE=2;
    private String selectedImagePath;
    private String mOwnerName;
    private String mOwnerEmail;
    //private String mOwnerId;
    private String mEmpID;
    private String mEmpName;
    private String mEmpEmail;
    private String mMerchID;
    private String mMerchName;
    private String mMerchAddr1;
    private String mMerchAddr2;
    private String mMerchAddr3;
    private String mMerchCity;
    private String mMerchState;
    private String mMerchZip;
    private String mMerchCountry;
    private String mMerchPhone;
    private String str_accessToken;
    private String str_storeID;
    private WebView myWebView;
    private int i_FirstLoad;                                            // Indicates app's First Load (prevents reloading on Resume)
    private String c_strCyberCouponsHost = "test.cybercoupons.com";     // Default to our test site
    private String c_strPOSID;
    private ProgressBar c_ctrlActivityIndicator;

    public static final String ACCESS_TOKEN_KEY = "access_token";
    public static final String MERCHANT_ID_KEY = "merchant_id";
    public static final String EMPLOYEE_ID_KEY = "employee_id";

    /* The GTN's POS IDs as of 12/22/2015 <CarlB>
    public enum POSEnvironment
    {
        Unknown =0,
        Clover = 1,
        Poynt = 2,
        CloverMini = 3,
        CloverMobile = 4
    }
    */
    private String c_strCloverStation = "1";
    private String c_strCloverMini = "3";
    private String c_strCloverMobile = "4";
    private String c_strErrorLine = "";

    public void LoadWebWebView(WebView myWebView, String accessToken)
    {
        try
        {
            c_strErrorLine = " (101)";
            String strURL;
            String strHost;
            String android_id = Secure.getString(getContentResolver(), Secure.ANDROID_ID);

            c_strErrorLine = " (102)";

            if (accessToken.length() > 0 && mMerchID.length() > 0)
            {
                c_strErrorLine = " (103)";

                if (str_storeID.length() > 0)
                {
                    c_strErrorLine = " (104)";
                    strURL = "http://" + c_strCyberCouponsHost + "/merchant/Login/CloverApp.aspx?POSID=" + c_strPOSID + "&token=" + accessToken + "&storeid=" + str_storeID + "&merchant_id=" + mMerchID + "&employee_id=" + mEmpID + "&email=" + mEmpEmail + "&android_id=" + android_id;
                }
                else
                {
                    c_strErrorLine = " (104)";
                    strURL = "http://" + c_strCyberCouponsHost + "/merchant/Login/CloverCallback.aspx?POSID=" + c_strPOSID + "&token=" + accessToken + "&merchant_id=" + mMerchID + "&employee_id=" + mEmpID + "&username=" + mEmpName + "&email=" + mEmpEmail + "&storename=" + mMerchName + "&storeaddr1=" + mMerchAddr1 + "&storeaddr2=" + mMerchAddr2 + "&storeaddr2=" + mMerchAddr2 + "&storeaddr3=" + mMerchAddr3 + "&storecity=" + mMerchCity + "&storestate=" + mMerchState + "&storezip=" + mMerchZip + "&storecountry=" + mMerchCountry + "&storephone=" + mMerchPhone + "&android_id=" + android_id;
                    //strURL = "http://" + c_strCyberCouponsHost + "/merchant/Login/CloverCallback.aspx?POSID=" + c_strPOSID + "&token=" + accessToken + "&merchant_id=" + mMerchID + "&employee_id=" + mEmpID + "&username=" + mEmpName + "&email=" + mEmpEmail + "&storename=" + mMerchName + "&storeaddr1=" + mMerchAddr1 + "&storeaddr2=" + mMerchAddr2 + "&storeaddr2=" + mMerchAddr2 + "&storeaddr3=" + mMerchAddr3 + "&storecity=Test&storestate=TE&storezip=98001&storecountry=" + mMerchCountry + "&storephone=" + mMerchPhone + "&android_id=" + android_id;
                }

                c_strErrorLine = " (105)";
                myWebView.loadUrl(strURL);
            }
            else
            {
                Toast.makeText(getApplicationContext(), "Unable to obtain a Merchant Account", Toast.LENGTH_LONG).show();
            }
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: LoadWebWebView Exception=" + ex.getMessage() + c_strErrorLine, Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        final AlertDialog.Builder adb = new AlertDialog.Builder(this);

        try
        {

            c_strErrorLine = " (101)"; // This helps pinpoint the last code execution before the error

            super.onCreate(savedInstanceState);

            i_FirstLoad = 1;

            c_strPOSID = c_strCloverStation; // Default to Clover Station, in case it's the Asus (Dev Device).

            // Determine the POS ID
            c_strErrorLine = " (102)";
            if (Platform.isCloverStation())
            {
                c_strPOSID = c_strCloverStation;
            }
            else if (Platform.isCloverMini())
            {
                c_strPOSID = c_strCloverMini;
            }
            else if (Platform.isCloverMobile())
            {
                c_strPOSID = c_strCloverMobile;
            }

            // Cause an Exception
            //mMerchAccount.getClass(); // Testing

            //if they haven't set their storeID and storePassword make them set it
            c_strErrorLine = " (103)";
            SharedPreferences prfs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            c_strErrorLine = " (104)";
            str_storeID = prfs.getString("Store_ID", "");
            c_strErrorLine = " (105)";
            String str_storePassword = prfs.getString("Store_Password", "");
            c_strErrorLine = " (106)";
            str_accessToken = prfs.getString("Access_Token", "");

            c_strErrorLine = " (107)";
            SharedPreferences preferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            c_strErrorLine = " (108)";
            SharedPreferences.Editor editor = preferences.edit();

            c_strErrorLine = " (109)";
            if (mMerchAccount == null)
            {
                mMerchAccount = CloverAccount.getAccount(this);
            }

            c_strErrorLine = " (110)";
            if (mMerchAccount != null)
            {
                mEmployeeConnector = new EmployeeConnector(this, mMerchAccount, null);
                mEmployeeConnector.connect();
                mMerchantDemographics = new MerchantConnector(this, mMerchAccount, null);
                mMerchantDemographics.connect();
            }
            else
            {   // Try Again?
                mMerchAccount = CloverAccount.getAccount(this);
            }

            // Get the merchant object
            c_strErrorLine = " (111)";
            getMerchant();

            // Get Merchant Demographics
            c_strErrorLine = " (112)";
            getMerchantDemographics();

            //otherwise load the merchant dashboard.
            c_strErrorLine = " (113)";
            setContentView(R.layout.activity_main);

            c_strErrorLine = " (114)";
            myWebView = (WebView) findViewById(R.id.webview);
            c_strErrorLine = " (115)";
            WebSettings settings = myWebView.getSettings();
            c_strErrorLine = " (116)";
            myWebView.getSettings().setPluginsEnabled(true);
            c_strErrorLine = " (117)";
            myWebView.getSettings().setAllowFileAccess(true);
            c_strErrorLine = " (118)";
            myWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
            myWebView.getSettings().setJavaScriptEnabled(true);

            //myWebView.getSettings().setSupportMultipleWindows(true); // This might help allow the Support Page to popup in a separate window.

            myWebView.addJavascriptInterface(new MyJavaScriptInterface(MainActivity.this), "HtmlViewer");

            myWebView.setOnKeyListener(new OnKeyListener() {
                @Override
                public boolean onKey(View v, int keyCode, KeyEvent event) {
                    if (event.getAction() == KeyEvent.ACTION_DOWN) {
                        WebView webView = (WebView) v;
                        switch (keyCode) {
                            case KeyEvent.KEYCODE_BACK:
                                if (webView.canGoBack()) {
                                    webView.goBack();
                                    return true;
                                }
                                break;
                        }
                    }
                    return false;

                }
            });
            myWebView.setWebChromeClient(new WebChromeClient() {
                //The undocumented magic method override
                //Eclipse will swear at you if you try to put @Override here
                // For Android 3.0+
                public void openFileChooser(ValueCallback<Uri> uploadMsg) {

                    mUploadMessage = uploadMsg;
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("image/*");
                    MainActivity.this.startActivityForResult(Intent.createChooser(i, "Select Picture"), FILECHOOSER_RESULTCODE);

                }

                // For Android 3.0+
                public void openFileChooser(ValueCallback uploadMsg, String acceptType) {
                    mUploadMessage = uploadMsg;
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    MainActivity.this.startActivityForResult(
                            Intent.createChooser(i, "Select Picture"),
                            FILECHOOSER_RESULTCODE);
                }

                //For Android 4.1
                public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {
                    mUploadMessage = uploadMsg;
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("image/*");
                    MainActivity.this.startActivityForResult(Intent.createChooser(i, "Select Picture"), MainActivity.FILECHOOSER_RESULTCODE);

                }

            });

            myWebView.setWebViewClient(new MyWebViewClient()
            {

                @Override
                public void onPageStarted(WebView view, String url, Bitmap favicon)
                {
                    // Show the Busy indicator
                    if (c_ctrlActivityIndicator != null)
                    {
                        c_ctrlActivityIndicator.setVisibility(View.VISIBLE);
                    }
                }

                @Override
                public void onPageFinished(WebView view, String url)
                {
                    // Hide the Busy indicator
                    if (c_ctrlActivityIndicator != null)
                    {
                        c_ctrlActivityIndicator.setVisibility(View.INVISIBLE);
                    }

                    myWebView.loadUrl("javascript:HtmlViewer.showHTML" +
                            "('<html>'+document.getElementsByTagName('html')[0].innerHTML+'</html>');");
                }


            });
            //}
        }
        catch(Exception ex)
        {
            //AlertDialog ad = adb.create();
            if (ex != null)
            {
                Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: onCreate Exception=" + ex.getMessage() + c_strErrorLine, Toast.LENGTH_LONG).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: onCreate Exception=NULL" + c_strErrorLine, Toast.LENGTH_LONG).show();
            }
            ex.printStackTrace();
        }
    }

    private class MyWebViewClient extends WebViewClient
    {

        //private WebView webView;

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url)
        {
            try
            {
                    if (url != null)
                    {
                        // This is your web site, so do not override; let the WebView to load the page
                        return false;
                    }
                    // Otherwise, the link is not for a page on my site, so launch another Activity that handles URLs
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                return true;
            }
            catch (Exception ex)
            {
                Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: MyWebViewClient::shouldOverrideUrlLoading Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
                ex.printStackTrace();
                return false;
            }

        }

        @Override
        public void onPageFinished(WebView view, String url)
        {
            super.onPageFinished(view, url);
        }
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon)
        {
            try
            {
                super.onPageStarted(view, url, favicon);
                if (url.contains("access_token=")) {
                    //save that code..., make them reinstall app if they get it wrong.
                    int index1 = url.indexOf("access_token=") + 13;
                    int index2 = url.length();

                    String stringholder = url.substring(index1, index2);

                    SharedPreferences preferences2 = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor2 = preferences2.edit();
                    editor2.putString("Access_Token", stringholder);
                    editor2.apply();

                    Intent intent = getIntent();
                    finish(); //you would think just after this is not reachable..
                    startActivity(intent);
                }
            }
            catch(Exception ex)
            {
                Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: MyWebViewClient::onPageStarted Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }

        }
    }

    class MyJavaScriptInterface
    {
        private Context ctx;

        MyJavaScriptInterface(Context ctx)
        {
            this.ctx = ctx;
        }

        @JavascriptInterface
        public void showHTML(String html)
        {
            try
            {
                if (html.indexOf("#STOREID#") > 0)
                {
                    SharedPreferences preferences2 = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor2 = preferences2.edit();

                    int index1 = html.indexOf("#STOREID#") + 9;
                    int index2 = html.indexOf("#/STOREID#");

                    String storeID = html.substring(index1, index2);

                    index1 = html.indexOf("#STOREPASSWORD#") + 15;
                    index2 = html.indexOf("#/STOREPASSWORD#");

                    String storePassword = html.substring(index1, index2);

                    editor2.putString("Store_ID", storeID);
                    editor2.putString("Store_Password", storePassword);
                    editor2.apply();
                }
                //}
            }
            catch (Exception ex)
            {
                Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: MyJavaScriptInterface::showHTML Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        }
    }

    final Runnable _setButton = new Runnable()
    {
        public void run()
        {
        }
    };
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        try
        {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.main, menu);
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: onCreateOptionsMenu Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        try
        {
            switch (item.getItemId())
            {
                case R.id.action_settings:
                    finish();
                    startActivity(new Intent(this, SettingsActivity.class));
                    return true;
                default:
                    return super.onOptionsItemSelected(item);
            }
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: onOptionsItemSelected Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        try
        {
            if (requestCode == FILECHOOSER_RESULTCODE)
            {
                if (null == mUploadMessage) return;
                Uri result = data == null || resultCode != RESULT_OK ? null
                        : data.getData();
                mUploadMessage.onReceiveValue(result);
                mUploadMessage = null;
                //Uri selectedImageUri = data.getData();
                //selectedImagePath = getPath(selectedImageUri);
            }

            if (requestCode == REQUEST_ACCOUNT && resultCode == RESULT_OK) {
                String name = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
                String type = data.getStringExtra(AccountManager.KEY_ACCOUNT_TYPE);
                mMerchAccount = new Account(name, type);
            }
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: onActivityResult Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    private void startAccountChooser()
    {
        try
        {
            Intent intent = AccountManager.newChooseAccountIntent(null, null, new String[]{CloverAccount.CLOVER_ACCOUNT_TYPE}, false, null, null, null, null);
            startActivityForResult(intent, REQUEST_ACCOUNT);
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: startAccountChooser Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }

    }

    @Override
    protected void onResume()
    {
        try
        {
            c_strErrorLine = " (101)";
            super.onResume();

            c_strErrorLine = " (102)";
            // Get a reference to the Activity Indicator control (busy icon)
            if (c_ctrlActivityIndicator == null) {
                c_ctrlActivityIndicator = (ProgressBar) findViewById(R.id.ctrlActivityIndicator);
            }

            c_strErrorLine = " (103)";
            if (mMerchAccount != null)
            {
                connect();
                createTender();
            } else
            {
                startAccountChooser();
            }

            c_strErrorLine = " (104)";
            // Get our Auth Code (formally Access Token)
            getCloverAuth();

            c_strErrorLine = " (105)";
            // Get the Logged In Employee
            getEmployee();
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: onResume Exception=" + ex.getMessage() + c_strErrorLine, Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    @Override
    protected void onPause()
    {
        try
        {
            disconnect();
            super.onPause();
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: onPause Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    private void connect()
    {
        try
        {
            disconnect();
            if (mMerchAccount != null)
            {
                tenderConnector = new TenderConnector(this, mMerchAccount, null);
                tenderConnector.connect();
            }
            if (mMerchAccount != null)
            {
                mEmployeeConnector = new EmployeeConnector(this, mMerchAccount, null);
                mEmployeeConnector.connect();
            }
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: connect Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    private void disconnect()
    {
        try {
            if (tenderConnector != null)
            {
                tenderConnector.disconnect();
                tenderConnector = null;
            }

            if (mEmployeeConnector != null)
            {
                mEmployeeConnector.disconnect();
                mEmployeeConnector = null;
            }
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: disconnect Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    private void getTenders()
    {
        try
        {
            tenderConnector.getTenders(new TenderConnector.TenderCallback<List<Tender>>() {
                @Override
                public void onServiceSuccess(List<Tender> result, ResultStatus status) {
                    super.onServiceSuccess(result, status);
                    String text = "Tenders:\n";
                    for (Tender t : result) {
                        text += "  " + t.getId() + " , " + t.getLabel() + " , " + t.getLabelKey() + " , " + t.getEnabled() + " , " + t.getOpensCashDrawer() + "\n";
                    }
                }

                @Override
                public void onServiceFailure(ResultStatus status) {
                    super.onServiceFailure(status);
                }

                @Override
                public void onServiceConnectionFailure() {
                    super.onServiceConnectionFailure();
                }
            });
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: getTenders Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    private void createTender()
    {
        try {


            final String tenderName = "Cyber Coupons";
            final String packageName = getPackageName();

            tenderConnector.checkAndCreateTender(tenderName, packageName, true, false, new TenderConnector.TenderCallback<Tender>() {
                @Override
                public void onServiceSuccess(Tender result, ResultStatus status) {
                    super.onServiceSuccess(result, status);
                    String text = "Custom Tender:\n";
                    text += "  " + result.getId() + " , " + result.getLabel() + " , " + result.getLabelKey() + " , " + result.getEnabled() + " , " + result.getOpensCashDrawer() + "\n";
                }

                @Override
                public void onServiceFailure(ResultStatus status) {
                    super.onServiceFailure(status);
                }

                @Override
                public void onServiceConnectionFailure() {
                    super.onServiceConnectionFailure();
                }
            });
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: createTender Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }
    private void getMerchant()
    {
        try {


            new AsyncTask<Void, Void, Employee>() {

                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                }

                @Override
                protected Employee doInBackground(Void... params) {
                    try {

                        SystemClock.sleep(500);

                        List<Employee> employees = mEmployeeConnector.getEmployees();

                        String l_strTmp;

                        for (Employee employee : employees) {
                            // Default to an Employee
                            //mOwnerName = employee.getName();
                            //mOwnerEmail = employee.getEmail();

                            if (employee.getIsOwner()) {
                                return employee;
                            }
                        }
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    } catch (ClientException e) {
                        e.printStackTrace();
                    } catch (ServiceException e) {
                        e.printStackTrace();
                    } catch (BindingException e) {
                        e.printStackTrace();
                    }
                    return null;
                }

                @Override
                protected void onPostExecute(Employee owner) {
                    super.onPostExecute(owner);

                    if (!isFinishing()) {
                        // Populate the owner information
                        if (owner != null) {
                            //mOwnerId = owner.getId();
                            mOwnerName = owner.getName();
                            mOwnerEmail = owner.getEmail();
                        }
                    }
                }
            }.execute();
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: getMerchant Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    private void getMerchantDemographics()
    {
        try {


            new AsyncTask<Void, Void, Merchant>() {

                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                }

                @Override
                protected Merchant doInBackground(Void... params) {
                    Merchant merchant = null;
                    try {
                        merchant = mMerchantDemographics.getMerchant();
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    } catch (ClientException e) {
                        e.printStackTrace();
                    } catch (ServiceException e) {
                        e.printStackTrace();
                    } catch (BindingException e) {
                        e.printStackTrace();
                    }
                    return merchant;
                }

                @Override
                protected void onPostExecute(Merchant merchant) {
                    super.onPostExecute(merchant);

                    if (!isFinishing()) {
                        // Populate the merchant information
                        if (merchant != null) {
                            mMerchID = URLEncoder.encode(merchant.getId());
                            mMerchName = URLEncoder.encode(merchant.getName());
                            mMerchAddr1 = URLEncoder.encode(merchant.getAddress().getAddress1());
                            mMerchAddr2 = URLEncoder.encode(merchant.getAddress().getAddress2());
                            mMerchAddr3 = URLEncoder.encode(merchant.getAddress().getAddress3());
                            mMerchCity = URLEncoder.encode(merchant.getAddress().getCity());
                            mMerchState = URLEncoder.encode(merchant.getAddress().getState());
                            mMerchZip = URLEncoder.encode(merchant.getAddress().getZip());
                            mMerchCountry = URLEncoder.encode(merchant.getAddress().getCountry());
                            mMerchPhone = URLEncoder.encode(merchant.getPhoneNumber());
                        }
                    }
                }
            }.execute();
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: getMerchantDemographics Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    private void getCloverAuth()
    {
        try {


            // This needs to be done on a background thread
            new AsyncTask<Void, Void, CloverAuth.AuthResult>() {
                @Override
                protected CloverAuth.AuthResult doInBackground(Void... params) {
                    try {
                        return CloverAuth.authenticate(MainActivity.this, mMerchAccount);
                    } catch (OperationCanceledException e) {
                        //Log.e(TAG, "Authentication cancelled", e);
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: getCloverAuth Exception=" + e.getMessage(), Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                        //Log.e(TAG, "Error retrieving authentication", e);
                    }
                    return null;
                }

                @Override
                protected void onPostExecute(CloverAuth.AuthResult result) {
                    mCloverAuth = result;

                    // To get a valid auth result you need to have installed the app from the App Market. The Clover servers
                    // only creates the token once installed the first time.
                    if (mCloverAuth != null && mCloverAuth.authToken != null) {
                        str_accessToken = mCloverAuth.authToken;

                        // Save the Token for use with Tendering and Transaction Processing
                        SharedPreferences preferences2 = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor2 = preferences2.edit();
                        editor2.putString("Access_Token", str_accessToken);
                        editor2.apply();
                    } else {
                        Toast.makeText(getApplicationContext(), "CyberCoupons Rewards must be installed from the Clover App Store.", Toast.LENGTH_LONG).show();
                        //mToken.setText("CyberCoupons Rewards must be installed from the Clover App Store.");
                        //mToken.setText(getString(R.string.auth_error));
                    }
                }

            }.execute();
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: getCloverAuth Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    private void getEmployee()
    {
        try {


            mEmployeeConnector.getEmployee(new EmployeeConnector.EmployeeCallback<Employee>() {
                @Override
                public void onServiceSuccess(Employee employee, ResultStatus status) {
                    if (employee != null) {
                        super.onServiceSuccess(employee, status);
                        mEmpID = employee.getId().toString();
                        mEmpName = employee.getName();
                        mEmpEmail = employee.getEmail();
                    }

                    // Load the Web View based on which variables we have set <CarlB>
                    if (i_FirstLoad == 1) {
                        LoadWebWebView(myWebView, str_accessToken);
                        i_FirstLoad = 0;
                    }
                }
            });
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: getEmployee Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }

    @Override
    public void onActiveEmployeeChanged(Employee employee)
    {
        try
        {
            if (employee != null)
            {
                mEmpID = employee.getId().toString();
                mEmpName = employee.getName();
                //employee.getRole().toString();
                mEmpEmail = employee.getEmail();
            }
        }
        catch(Exception ex)
        {
            Toast.makeText(getApplicationContext(), "CyberCoupons Rewards: onActiveEmployeeChanged Exception=" + ex.getMessage(), Toast.LENGTH_LONG).show();
            ex.printStackTrace();
        }
    }
}
